import telebot
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Telegram Bot Token (replace with your own from @BotFather)
TELEGRAM_TOKEN = '7081422232:AAEPHhhanHIVlJwCR1hhz5c_AOY-hG0ok_o'

# Instagram Credentials
INSTAGRAM_USERNAME = 'your_instagram_username'
INSTAGRAM_PASSWORD = 'your_instagram_password'

bot = telebot.TeleBot(TELEGRAM_TOKEN)

def upload_to_instagram(video_path, caption=""):
    options = Options()
    options.add_argument("--headless")  # Run in background
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    
    try:
        # Go to Instagram
        driver.get("https://www.instagram.com/")
        time.sleep(3)
        
        # Login
        username_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "username"))
        )
        username_field.send_keys(INSTAGRAM_USERNAME)
        password_field = driver.find_element(By.NAME, "password")
        password_field.send_keys(INSTAGRAM_PASSWORD)
        login_button = driver.find_element(By.XPATH, "//button[@type='submit']")
        login_button.click()
        time.sleep(5)
        
        # Handle "Save Info" and "Turn on Notifications" if they appear
        try:
            save_info_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//button[text()='Save Info']"))
            )
            save_info_button.click()
        except:
            pass
        
        try:
            not_now_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//button[text()='Not Now']"))
            )
            not_now_button.click()
        except:
            pass
        
        # Go to Reels upload
        driver.get("https://www.instagram.com/create/reel/")
        time.sleep(3)
        
        # Upload video
        upload_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//input[@type='file']"))
        )
        upload_input.send_keys(video_path)
        time.sleep(10)  # Wait for upload
        
        # Add caption
        if caption:
            caption_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//textarea[@placeholder='Write a caption...']"))
            )
            caption_field.send_keys(caption)
        
        # Share
        share_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[text()='Share']"))
        )
        share_button.click()
        time.sleep(10)  # Wait for sharing
        
        return "Reel uploaded successfully!"
    
    except Exception as e:
        return f"Error uploading: {str(e)}"
    
    finally:
        driver.quit()

@bot.message_handler(content_types=['video'])
def handle_video(message):
    try:
        # Download video from Telegram
        file_info = bot.get_file(message.video.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        video_path = f"temp_{message.video.file_id}.mp4"
        with open(video_path, 'wb') as f:
            f.write(downloaded_file)
        
        # Optional: Get caption from message
        caption = message.caption if message.caption else ""
        
        # Upload to Instagram
        result = upload_to_instagram(video_path, caption)
        
        # Clean up
        os.remove(video_path)
        
        bot.reply_to(message, result)
    
    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

if __name__ == "__main__":
    bot.polling()